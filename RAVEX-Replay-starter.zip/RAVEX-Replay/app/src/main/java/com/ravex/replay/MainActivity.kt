package com.ravex.replay

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(12, 12, 14))
        }

        val brand = TextView(this).apply {
            text = "RAVEX"
            textSize = 34f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            letterSpacing = 0.16f
        }
        val subtitle = TextView(this).apply {
            text = "INSTANT GAMEPLAY REPLAY"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
        }
        val status = TextView(this).apply {
            text = "Prototype screen — replay capture is not implemented yet."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 36, 0, 24)
        }
        val button = Button(this).apply {
            text = "START SETUP"
            isAllCaps = false
            setOnClickListener {
                status.text = "Next milestone: screen-capture permission and foreground service."
            }
        }
        val duration = TextView(this).apply {
            text = "Target replay duration: 60 seconds"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }

        root.addView(brand)
        root.addView(subtitle)
        root.addView(status)
        root.addView(button)
        root.addView(duration)
        setContentView(root)
    }
}
